# Publisher Root Trust Policy

Package publisher keys are not self-authorizing. Their trust store must be carried by a root-signed publisher trust epoch.

## Bootstrap

Production Evercraft OS should pin at least one Ed25519 publisher-root public key through a release mechanism outside the mutable publisher trust store. Root private keys must remain outside the runtime package and outside ordinary node state.

## Publisher trust epochs

Each publisher trust epoch contains the complete product-scoped publisher keyring, its self-hash, a monotonic epoch number, a previous-epoch hash, and the root key ID that signed it.

The accepted epoch history is append-only and head-checkpointed. Rollback, skipped epochs, history truncation, invalid root signatures, and unpinned roots fail closed.

## Root rotation

A root rotation requires two signatures over the same rotation body:

- the current root authorizes the handoff;
- the incoming root proves possession of its private key.

The rotation chain is monotonic and hash-linked. Each accepted publisher trust epoch records the exact root-registry checkpoint that authorized it.

After rotation, the previous root may verify historical epochs but is not the current root for future epoch acceptance.

## Revocation behavior

Staged packages are re-verified against the current publisher trust epoch before activation and whenever active-package integrity is inspected. A publisher key revoked after staging causes that package to become held.

Root and publisher signatures grant no installation, update, rollback, execution, payment, or device authority. Those remain separate Systemia and Passport concerns.
