# Evercraft OS Lifecycle Hardening | local candidate

Prepared: 2026-10-10
Status: REVIEW_HELD, unmerged, not deployed

## Provenance
- Recovered from Library archive `evercraft-os-package-trust-20261010.zip`.
- Recovered source ZIP SHA-256: `8caefcffb6cead055ff94ce3bf0dbc5988891ddb1182a868ad200209be6de76b`.
- Original recovered source's `SHA256SUMS.txt` verified before modifications.
- Original local suite independently rerun: 62 tests, 62 passing, 0 failing.
- Original README, receipt, and exact transcript are preserved in `BASELINE_RECEIPT.json` and `BASELINE_TEST_RESULTS.txt`; original README remains with an added hardening notice.

## Changes and security invariants

1. `home-package-orchestrator.mjs`:
   - Check hash-chain/head integrity **before** computing desired state.
   - Convert current-state failures into explicit `held_transition_state` status rather than throwing or asserting alignment.
   - Only report desired-active alignment if the *exact transition receipt* on the activation pointer matches the latest ledger receipt, not merely if fingerprints match.
   - Busy/unverified transition-writer and pending/failed recovery-inspection states hold alignment rather than advertising a settled state.
   - Preserve false process-start/runtime-health/execution-authority claims.
2. `package-store.mjs`:
   - Reject symlinks and linked/non-regular staged blobs, staged manifests, staging directories and activation pointers. Matching content hashes alone cannot prove owned materialization.
   - fsync staged blobs and atomic JSON before renaming; best-effort directory fsync on supported filesystems. No claim of transactional durability on every filesystem.
3. `home-package-recovery.test.mjs`: make the old mock expectation fail closed on busy writer instead of calling it aligned.
4. `home-package-status-integrity.test.mjs`: six regression tests, designed to fail on the previous behavior, for checkpoint corruption, stale activation lineage, off-store blob symlinks, activation pointer symlinks, thrown recovery inspection, and unresolved recovery intent.

## Test interpretation

- This is local Node unit/integration proof. NOT a proof of the user's Chromebook or HP OS, production signing keys, device enrollment, public ingress, service liveness, canonical GitHub main integration, or remote CI.
- The repository is inaccessible via the connected account due to a suspension-related GitHub 403. No merge, branch write or deployment is claimed.
- The recovered `systemia/passport/passport.mjs` is a standalone test dependency only. DO NOT overwrite canonical Passport.
- Tests create ephemeral Ed25519 keypairs only. No production signing private keys are stored or shipped.

## Landing and acceptance

1. Systemia mission/admission record and review receipt.
2. Merge/rebase *additively* to `systemia/evercraft-os/` after canonical source access is restored.
3. Reconcile `Passport`, existing installed-state authority, Home server Identity/CSRF/session, capability capsules/Execution Gate, RootTrust bootstrap, and OS boot contracts.
4. Run the exact local tests and full canonical repository CI against the actual current tree.
5. Run adversarial multi-process power-loss, NFS/overlayfs durability, symlink, cross-node replay, trust-epoch revocation and actor/permit-boundary tests in the target environment.
6. Gate rollout on production key ceremony, immutable root key distribution, node enrollment, scoped runtime execution permits, independent health attestation, and rollback rehearsals.
