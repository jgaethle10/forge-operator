# Upstream Integration Map

This candidate should land as a separate Evercraft OS lifecycle slice after the Linux user-session boot work and Raven/Home compatibility repair are reconciled with current repository source.

## Rebase rule

Do not copy the included recovered Passport source over a newer canonical Passport implementation. Rebase these modules against current `main` and adapt to the live Passport API while preserving exact scope, resource, and request-fingerprint bindings.

## Additive source files

Place or reconcile under `systemia/evercraft-os/`:

- `package-trust.mjs`
- `publisher-root-registry.mjs`
- `publisher-trust-epoch.mjs`
- `package-store.mjs`
- `package-transition-ledger.mjs`
- `package-transition-recovery-inspector.mjs`
- `package-transition-recovery.mjs`
- `process-instance.mjs`
- `home-package-lifecycle.mjs`
- `home-package-orchestrator.mjs`
- `home-package-recovery.mjs`
- matching `.test.mjs` files

`publisher-trust-test-helper.mjs` is test-only and must never be used as a production key ceremony.

## Required existing contracts

- Evercraft Identity authenticates the actor.
- Passport mints and consumes exact single-use permits.
- Existing OS install ledger remains baseline installed-state authority.
- Capability capsules remain runtime mediation.
- Systemia remains mission authority.
- Home remains a preparation/status surface rather than the authorization source.

## Passport scopes introduced or required

Existing lifecycle scopes:

- `app.update`
- `app.rollback`

Recovery scopes:

- `app.recover.head`
- `app.recover.writer`

Do not alias recovery to update or rollback. Recovery changes authority-bearing ledger/checkpoint state and requires separate policy review.

## Root trust bootstrap

Production integration must instantiate `EvercraftOsPublisherRootRegistry` with a public bootstrap root key delivered outside the mutable publisher-keyring state. Then instantiate `EvercraftOsPublisherTrustEpochStore` with that root registry. `EvercraftOsPackageStore` and `EvercraftHomePackageLifecycle` should receive the epoch store, not a raw trust object.

Do not ship root private keys in repository fixtures, release bundles, environment defaults, or Home configuration.

## CI additions

Run every `systemia/evercraft-os/*.test.mjs` test, plus the broader current-repository gates for:

- Passport
- Identity
- Evercraft Home sovereignty
- Execution Gate
- Capability Mesh
- NodeSeed / Local Organism
- Evercraft OS boot/session proofs
- Forge checks / portfolio sentinel

Current local candidate result: 62/62 tests pass.

## Home HTTP surface

Do not wire mutation endpoints until current `server.mjs`, Identity, CSRF/session boundaries, and current Passport scope enforcement are reviewed together.

Recommended shape:

1. read-only package/runtime/recovery status;
2. prepare update/rollback/recovery plan;
3. separate authorization flow producing an exact Passport permit;
4. apply endpoint that accepts only that permit and exact plan fingerprint;
5. return transition/recovery receipt and desired-vs-active status.

An HTTP request must never mint its own authority inside the same handler that performs the mutation.

## Remaining production gaps

- no current-repository rebase while GitHub is suspended;
- no live-device rollout;
- no production root-key or publisher-key ceremony;
- no hardware-backed key storage;
- no executable/process activation from package metadata;
- no current capability-capsule reconciliation against the canonical repository;
- no claim that activation metadata equals runtime health.

## October 11 runtime handoff candidate (additive, never active by default)

- `runtime-handoff.mjs` + `runtime-handoff.test.mjs`: read-only plan and independently pinned-node claim observation.
- `runtime-independent-gates.mjs` + `runtime-independent-gates.test.mjs`: four distinct pinned signers and plan-bound role attestations.
- `RUNTIME_HANDOFF_POLICY.md`: threat model and missing production links.

**DO NOT wire these candidate modules into a production launch endpoint.** They validate local proof shapes, but signer enrollment, canonical authorization flow, authoritative process creation, durable admission and runtime health still require integration and independent review.

## Separate review-held lab supervisor candidate (2026-10-12)

`runtime-lab-supervisor.mjs` and its two fixture scripts plus `.test.mjs` implement an isolated non-root Linux test-only process lifecycle exercise. Do not install or import it into production Home, NodeSeed, Passport or Execution Gate. It is not a general executable launcher. See `RUNTIME_LAB_SUPERVISOR_POLICY.md` and its receipt for unproven guarantees and future threat-model work.


## Additional 2026-10-13 detached witness integration candidate (review held)

- Add `runtime-lab-external-witness.mjs` and matching tests to the existing lab-only OS test suite.
- Only enable `witnessMode: external_required` when the OS host genuinely supplies a separate trusted witness source AND a separately pinned committed digest. Do not source the digest from the mutable journal folder or from package metadata.
- No public release or executable expansion until independent witness custody, monotonically consistent watermarks, immutable executable identity, actual Linux confinement, operational incident runbooks and new real-world authority reviews exist.
- Strict mode requires an external anchor refresh after each lifecycle journal advance. Absence of the refreshed commitment is a hold, not a reason to bypass the gate.
- Do not mistake the test-only signer for production trust or overwrite newer canonical Passport code from the proof archive.
