# OS Desired State Is Not Runtime Health

The `EvercraftHomePackageOrchestrator.status` API reports metadata *alignment*, never process activation.

The following are required simultaneously for `state=aligned`:
- Transition event chain and head checkpoint verify.
- Current desired installed state can be derived from the verified journal.
- Staged active package and activation pointer are verified using the currently accepted, anchored publisher trust epoch.
- Package fingerprints match, AND the activation pointer's `transition_receipt_hash` exactly matches the ledger's current `last_transition_receipt_hash`.
- Transition writer lock is free.
- If attached, read-only recovery inspector explicitly reports `clean`.

Any missing condition is a hold or drift. `held_transition_integrity`, `held_transition_state`, `held_activation_integrity`, `held_transition_writer`, `held_recovery_evidence`, `held_activation_lineage`, `not_installed`, and `desired_active_drift` are distinct statuses.

Staged blobs, manifest and activation pointer must be ordinary owned files, not symlinks or hardlinked files with matching bytes. Directory symlinks in the owned staging subtree are rejected. This is necessary but not sufficient for hostile-filesystem resistance: no production adversarial-user or filesystem threat claim is made.

A metadata `aligned` state does NOT assert `process_started`, `runtime_health`, valid execution permit, capsule enrollment, sandbox isolation, successful checkout, or running code. Those require independent future evidence and explicit Systemia/Passport/Execution Gate mediation.

No auto-repair, process kill, arbitrary command dispatch, root-key private material or runtime launch code is added in this candidate.
