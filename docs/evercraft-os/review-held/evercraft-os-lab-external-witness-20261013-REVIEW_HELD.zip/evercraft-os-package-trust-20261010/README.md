# UPDATE: Detached Lab Witness Candidate | 2026-10-13 | REVIEW HELD

The **current inherited suite passes 169/169 offline tests** under a non-root Linux user. This package extends the prior 148-test crash-journal archive with a detached, Ed25519-signed external witness verifier (`runtime-lab-external-witness.mjs`) and an opt-in strict supervisor mode (`witnessMode: external_required`). It checks exact journal identity, sequence, head digest, expiry, and a separately supplied commitment before lab launch/stop permit consumption or recovery inspection. **Independent external custody and freshness are simulated in tests only**; this package is not production anti-rollback, deployment approval, or a release. Read `RUNTIME_LAB_EXTERNAL_WITNESS_POLICY.md` for the boundaries.

The original 62-test section below describes a historical earlier package and remains preserved for source lineage.

---

# Evercraft OS Package Trust, Recovery, and Root Rotation Candidate

Prepared: 2026-10-10
Status: local recovery candidate, not merged upstream

This package extends the Evercraft OS lifecycle boundary from signed package staging and reversible update/rollback into explicit crash recovery and root-anchored publisher trust.

## Authority chain

```text
OS-pinned publisher root key
  -> dual-signed root rotation registry
  -> monotonic root-signed publisher trust epoch
  -> product-scoped publisher key
  -> signed package attestation
  -> content-addressed inert staging
  -> Home prepares exact update/rollback request
  -> Passport single-use app.update or app.rollback permit
  -> serialized transition journal
  -> activation metadata reconciliation
  -> desired-vs-active status

crash/recovery path
  -> read-only transition recovery inspection
  -> exact recovery plan bound to observed evidence
  -> Passport single-use app.recover.head or app.recover.writer permit
  -> fsynced recovery intent
  -> permit consumption
  -> deterministic repair
  -> hash-chained recovery completion receipt
```

Systemia remains mission authority. Passport remains mutation authority. Publisher signatures establish package provenance only. Root signatures establish publisher-keyring provenance only. Home may inspect, prepare, and apply a caller-authorized operation, but it cannot mint its own update, rollback, or recovery authority.

## Current proof state

The local Node suite passes **62/62 tests**.

The proof surface covers:

- Ed25519 publisher package attestations;
- product-scoped publisher keys;
- publisher key revocation;
- root-signed publisher trust epochs;
- trust-epoch rollback and truncation detection;
- dual-signed root rotation with incoming-key proof of possession;
- rejection of an old root after rotation for newer trust epochs;
- rejection of raw unanchored trust-store configuration by the package store;
- re-verification of staged packages against the current trust epoch before activation;
- revocation after staging causing the package to become held;
- content-addressed inert package staging;
- staged-blob tamper detection;
- separate single-use Passport `app.update` and `app.rollback` permits;
- append-only transition history with hash chain and head checkpoint;
- exclusive transition writer serialization before permit consumption;
- real Linux process-instance identity using boot ID, PID, and `/proc` start ticks;
- PID reuse and reboot distinction;
- read-only recovery classification;
- explicit `app.recover.head` and `app.recover.writer` recovery scopes;
- writer-lock recovery only when exact process-instance evidence proves the original writer is gone and the lock is old enough;
- deliberate refusal to recover legacy locks that lack process-instance evidence;
- crash after recovery permit consumption, resumed with the same consumed authority;
- crash after repair mutation, resumed as `observed_already_applied` and closed with a completion receipt;
- Home recovery inspection/preparation without permit minting;
- desired package vs active package drift reporting;
- reversible activation metadata and rollback to a previously verified staged package.

## Recovery design

Recovery is an authority-bearing operation, not cleanup.

A checkpoint repair or stale writer-lock clear requires a dedicated recovery plan fingerprint and a distinct Passport permit. Recovery writes an intent before consuming the permit. If power disappears after permit consumption, the same operation can resume without minting a second permit. A conflicting incomplete recovery intent blocks another recovery operation.

Writer-lock clearing is narrower than PID checking. New transition locks include a Linux process-instance identity composed from the boot ID and `/proc/<pid>/stat` start time. A PID that now belongs to another process is treated as reused, not as the old writer. A lock without this evidence remains held.

## Root trust design

The package store no longer accepts a raw publisher trust store. Its trust provider must be an `EvercraftOsPublisherTrustEpochStore`.

Publisher trust epochs are signed by a root key and stored in a monotonic append-only chain. Root rotation is separately append-only. A rotation requires both:

1. a signature from the currently authorized root; and
2. a proof-of-possession signature from the incoming root.

Each trust epoch accepted through a root registry is bound to the exact root-registry checkpoint that authorized it. After a root rotates, the old root remains available only for historical verification and cannot sign a newer trust epoch.

No root or publisher private key material is persisted in this candidate.

## Files

Primary modules under `systemia/evercraft-os/`:

- `package-trust.mjs`
- `publisher-root-registry.mjs`
- `publisher-trust-epoch.mjs`
- `package-store.mjs`
- `package-transition-ledger.mjs`
- `package-transition-recovery-inspector.mjs`
- `package-transition-recovery.mjs`
- `process-instance.mjs`
- `home-package-lifecycle.mjs`
- `home-package-orchestrator.mjs`
- `home-package-recovery.mjs`
- matching `.test.mjs` files
- `publisher-trust-test-helper.mjs`, test-only ephemeral key setup

The included `systemia/passport/passport.mjs` is a recovered proof dependency. It must not overwrite a newer canonical Passport implementation during upstream integration.

## Truth boundary

This candidate is not merged into `jgaethle10/forge-operator` because the connected GitHub account is returning a suspension-related 403. It has not been deployed to the founder Chromebook or another production node. It does not start an executable, enable a service, establish public ingress, mint production signing keys, or claim runtime health.

Activation in this candidate is metadata reconciliation. Runtime launch remains behind the existing capability capsule and Systemia execution path.

## October 10 lifecycle hardening follow-up

This archive is a **locally extended, review-held** follow-up to the 62/62 recovery/root-rotation candidate documented above. The new proof and trust boundaries are in `HARDENING_CHANGELOG.md` and `STATUS_INTEGRITY_POLICY.md`. `TEST_RESULTS.txt` contains the new full test transcript. The original transcript and receipt are preserved as `BASELINE_TEST_RESULTS.txt` and `BASELINE_RECEIPT.json`.

This candidate is not a code merge, a deployed OS update, or a runtime launch.

## October 11 runtime-handoff verification follow-up

This sealed follow-up to the 68/68 lifecycle-hardening archive adds a **read-only runtime handoff and independently signed gate-evidence verifier**. The full local suite now passes **107/107 tests**. No execution, service launch, Passport permit issuance, device deployment, or health declaration was performed. See `RUNTIME_HANDOFF_POLICY.md` and `RUNTIME_HANDOFF_RECEIPT.json` for exact boundary, new files, provenance and verification.

## Additive local lab process supervisor candidate (2026-10-12)

A separately review-held, non-root Linux-only fixture supervisor now provides real `spawn`/IPC readiness/stop tests with exclusive app locks, one-use lab permits, independent four-role format checks, and process-instance identity verification. The lab permit is **not** production Passport authorization and the fixture is **not** sandboxed. See `RUNTIME_LAB_SUPERVISOR_POLICY.md` and `RUNTIME_LAB_SUPERVISOR_RECEIPT.json`. Never install this test harness as a production OS executable adapter.

## October 12 offline crash-evidence hardening (review-held, 148 tests)

An additive lab-only lifecycle journal (`runtime-lab-journal.mjs`) now commits hash-chained events and a separately fsynced checkpoint, checks both before authorizing subsequent lab operations, and exposes a read-only integrity result. The process supervisor leaves a lock held if process-exit evidence cannot be written. A separate read-only `inspectRecovery` endpoint reports ambiguous locks and Linux process observations; it **never clears a lock, kills a process, or mints a recovery permit**. Eighteen new tests exercise tampering, truncation, symlinks/hardlinks, writer contention, and fail-closed launch/stop/exit integration.

The locally reproduced full suite is **148/148 passing under an unprivileged Linux user**. This archive is not merged, distributed as a production release, or deployed to the HP/Chromebook. See `RUNTIME_LAB_CRASH_JOURNAL_POLICY.md`, `RUNTIME_LAB_CRASH_JOURNAL_RECEIPT.json`, and `TEST_RESULTS.txt`. The previous 130-test transcript and SHA256 inventory remain in `PREVIOUS_130_*` files. **Local journal hashes are not external attestation**: a same-UID adversary with access to both journal and checkpoint can rewrite both; there is no sandbox or independently anchored signing.
