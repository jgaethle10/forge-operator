# Evercraft OS detached witness | review-held engineering proof

Prepared: 2026-10-13. State: OFFLINE / SOURCE CANDIDATE / REVIEW HELD.

## Exact new boundary

`systemia/evercraft-os/runtime-lab-external-witness.mjs` verifies an Ed25519-signed, domain-separated, exact-sequence/heading-hash witness envelope against a separately trusted public key **and** a separately supplied commitment digest. It does not create or sign attestations, store any signing private key, contact a service, or change journal files. The external-source function is injected by a trusted host. In `external_required` mode, the lab supervisor invokes this gate before consuming a launch or stop permit; read-only crash recovery inspection also rejects absent or stale witness evidence.

Witness body includes `schema`, `journal_id`, `sequence`, `head_hash`, `issued_at`, `expires_at`, and `witness_epoch`. The maximum permitted validity interval is 120 seconds. The detached commitment covers the whole signed receipt, not merely its body. A recomputed local hash by itself is **never** treated as an externally committed receipt.

If witness evidence is unavailable, expired, forged, from the wrong journal, older than the current log, or divergent from the current head, the supervisor holds rather than consuming new permits. A newer signed witness must be supplied when lifecycle activity advances the local chain. This is intentionally conservative.

## What the tests actually establish

An attacker able to rewrite BOTH local journal and checkpoint into an internally consistent history still fails strict inspection if the latest separately pinned receipt describes the original journal. A replayed old legitimate signed receipt fails if compared with the latest independently pinned digest. A fabricated witness gate object cannot replace the verifier in strict supervisor mode.

## Where the trust *must* live

Real independent anchoring requires: a separate witness process/service with independent signing key custody, strict authenticated ingress, a monotonic append-only commitment/high-water record (including journal identity and epoch), fresh reads from that trusted custodian, and external rollback/recovery review. None of those services, key ceremonies, remote durable stores, or hardware trust roots were provisioned or proved here. The test harness alone supplies in-memory ephemeral signing keys and simulated independently pinned commitments.

If the host returns an attacker-controlled old receipt AND a matching old commitment, signature verification alone **cannot** detect the rewind. Nor can this proof prevent privileged or same-UID filesystem races, prove process/application health, implement Linux isolation, or replace real Passport, Execution Gate, NodeSeed, and Systemia authority. The older `legacy_local` mode remains explicitly labeled unanchored for compatibility with the previous 148-test candidate. Do not use it for production workloads.

## Canonical integration rule

Do not allow production execution until the actual OS host obtains the newest independent witness through a separately authenticated source, enforces monotonic external high-water custody, uses real pinned issuer keys outside app/package metadata, implements confined execution, and reconciles with canonical repository tests/CI and physical-device admission. A Drive archive is an artifact backup, **not** a witness service, live permission or secure signing authority.

## Reproducible tests

Run as an **unprivileged Linux user**, with Node 22 or newer:

```sh
sha256sum -c SHA256SUMS.txt
node --test systemia/evercraft-os/*.test.mjs
```

No founder HP/Chromebook deployment, no root execution, no public route, no real signing key, no auto-recovery, no upstream merge.
