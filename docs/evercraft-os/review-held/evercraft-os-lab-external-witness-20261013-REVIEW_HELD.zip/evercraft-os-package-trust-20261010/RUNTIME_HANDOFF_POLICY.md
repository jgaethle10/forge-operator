# Evercraft OS Runtime Handoff v0.1 | REVIEW HELD

Prepared: 2026-10-11
Status: local, offline code-and-test candidate. No upstream merge. No launch authority. No deployment.

## What actually changed

The 68-test package lifecycle baseline now has two additive modules:

* `systemia/evercraft-os/runtime-handoff.mjs` (24 new adversarial tests in `runtime-handoff.test.mjs`)
* `systemia/evercraft-os/runtime-independent-gates.mjs` (15 new adversarial tests in `runtime-independent-gates.test.mjs`)

Total local test suite: 107/107 passing, 0 failing.

## Separation of authority

```
package signed and current -> staging integrity verified -> transition receipt exact
    -> runtime handoff plan (no authority)
    -> recheck exact package, activation, transition, publisher trust epoch,
       capsule contract hash, device attestation hash, Systemia/Execution Gate references
    -> four independent signed decision attestations, each bound to exact plan
    -> 'evidence verified for Passport review' ONLY
    -> NOT YET BUILT: canonical Systemia admission, Passport runtime permit,
       Execution Gate policy enforcement, NodeSeed attestation, capsule binding,
       privileged supervisor admission, service launch, health/liveness checks,
       process lineage receipt, revoke/kill/restart, rollback integration
```

A plan's SHA-256, publisher package signature, or an authenticated process claim alone is never a permit to execute. Signed off-chain role decisions are neither authorization to launch nor proof that a service is healthy. Production versions must prove the signers are real, enrolled, independently authorized entities before relying on decisions.

## Runtime plan guarantees

Each preparatory plan binds exact product/node/subject/capability, package fingerprint, activation hash, transition receipt, transition ledger head, publisher epoch hash, staged verification receipt, capsule contract fingerprint, Systemia mission receipt fingerprint, Execution Gate policy fingerprint, and device attestation fingerprint. It has an unpredictable challenge nonce, a five-minute validity limit, and a canonical SHA-256 plan digest.

A revalidation re-reads independently verified live local package/transition state. Any change to bound snapshots, unresolved writer or recovery state, staged data, signature trust epoch, plan integrity, subject, or freshness holds. There are no filesystem writes, Passport calls, process starts, service toggles, network calls or credential changes in these new modules.

**Important limitation:** A caller-provided SHA reference by itself is not evidence of an authorized decision. This is why the independent signed gate bundle exists.

## Independent signed decisions

The gate verifier requires four distinct, OS-pinned Ed25519 verification keys and exactly four matching signed decisions, with domains for `systemia`, `execution_gate`, `capsule`, and `nodeseed`. It rejects use of a shared key across roles, missing or extra attestations, stale decisions, denials, cross-role signatures, altered fields, and mismatched exact plan/resource references. It uses a two-minute maximum attestation lifetime; decisions must be issued after the referenced plan is prepared. No private keys are included in runtime modules or artifacts. Ephemeral keys in `.test.mjs` files are *tests only*.

This verifies the cryptographic format under simulated keys. The canonical Systemia/Execution Gate/capsule/NodeSeed services have not been integrated or enrolled; these are placeholder trust roles, not existing production approvals.

## Process identity observation, not service health

The optional node-signed process observation verifies an Ed25519 signature against an independently pinned node public key and matches its report to the exact handoff nonce and transition identity. On Linux, it checks boot ID, PID, and `/proc` start ticks to distinguish live process identity from PID reuse and reboot. It does not prove that the observed process was launched by Evercraft, belongs to the package, is confined, is responding correctly, has passing health probes, is authorized to execute, or can survive reboot. Outputs explicitly keep `process_started_claimed`, `runtime_health_claimed` and `execution_authority_granted` false.

## Next integration requirements (not in this patch)

1. Systemia mission authority and current policy receipts, accepted through canonical registry rather than references.
2. Real enrolled NodeSeed and publisher-root key distribution, with out-of-band anchored trust; no fixture keys.
3. Passport `app.runtime.launch` or equivalent deliberately reviewed single-use scope, bound to plan, actor, device and job, with crash-safe intent and permit consumption.
4. Existing Execution Gate and capability capsule mediating *every* executable, device, network, process and payment permission separately. Do not bypass gate via OS metadata or REST.
5. Privilege-separated supervisor with hardened executable admission, immutable artifact selection, no-shell process creation, restricted uid/cgroups/namespaces, trustworthy executable content verification, no symlink traversal, unprivileged health checks, and authenticated process-to-job binding.
6. Recovery/stop/rollback permits and journal that distinguish authorized launch, observed process, liveness, readiness, health, recovery and revocation.
7. Canonical CI, adversarial multi-process tests, actual HP/Chromebook Linux proof and physical rollback trial.

## Truth boundary

No canonical repo merge, CI, production signing key, production Systemia permit, runtime authority, service start or successful production health is claimed. GitHub `jgaethle10/forge-operator` remains blocked by account-suspension 403 on recheck. The included `systemia/passport/passport.mjs` is a recovered test dependency, NOT a replacement for current canonical Passport.
