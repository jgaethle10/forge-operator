# Evercraft OS laboratory crash-evidence journal | review-held

Prepared: 2026-10-12
Status: OFFLINE / LAB-ONLY / REVIEW HELD. NOT DEPLOYED OR MERGED.

## Added engineering boundary

- `EvercraftOsLabLifecycleJournal` maintains a bounded JSONL event history with deterministic SHA-256 entry chaining and a separate fsynced checkpoint. Both undergo structural and content verification before additional append operations.
- A create-exclusive global audit writer reservation serializes append operations across local workers. This reservation is not automatically broken on process failure. Symlinks, hardlinks and nonregular journal/checkpoint files are rejected.
- Supervisor launch checks journal integrity and writer reservation before taking a workload lock or consuming the signed LAB permit.
- Supervisor stop checks journal integrity and writer reservation before consuming its separately signed LAB stop permit.
- If an exit audit cannot be committed, the supervisor does not release that workload's lock. This prevents unreviewed re-execution on a damaged local audit trail.
- `inspectRecovery()` reads existing lock and process-instance evidence without mutation, signaling, or authority minting. Even a process that is absent is not automatically judged safe to restart.
- Prior control-plane invariants are retained: four test-enrolled signatures, separate lab permits, non-root fixture only, PID+boot ID+start-ticks, exact hash-pinned script+Node runtime, no untrusted executable.

## Crash states intentionally held

1. Journal record appended but checkpoint absent or stale.
2. Partial trailing JSON line or a truncated event chain.
3. Rewritten event/checkpoint, symlink/hardlink, or unresolved audit writer reservation.
4. Orphan workload lock, even if a previously seen process has exited.
5. Exit observed without durable audit receipt.

Do not automatically clear locks, kill processes, replay consumed permits, or synthesize missing events. The verifier does not prove that a process is healthy; IPC readiness is fixture-only.

## Explicit limits

This is **not** a sandbox, and introduces no seccomp, cgroup isolation, network namespace, mount namespace, privilege-separated worker, immutable exec fd, secret vault, or production admission path. `spawn()` still has a path-to-exec race and the child runs under the calling non-root UID.

The local hash chain and checkpoint share a filesystem and trust domain. They detect inconsistent/tampered individual records, but are **not** immutable against a hostile same-UID writer who can replace both. No independently witnessed checkpoint, hardware-backed signing, anti-rollback quorum, remote attestation, or cross-host consensus exists.

Journal operations are synchronous and intentionally bounded to 4 MiB; the read-verify-on-append design is a small-scale proof, not a high-throughput log. The preflight journal check cannot eliminate all inter-process races, and local authorities remain synthetic test enrollments. Existing crash locks require separate human-approved recovery architecture.

## Verification commands

Use an unprivileged Linux user with Node 22+:

```sh
node --test systemia/evercraft-os/*.test.mjs
sha256sum -c SHA256SUMS.txt
```

Test archive must not contain production signing keys. This candidate has not run canonical CI and has not been deployed to founder hardware.

## Next work

1. Independent checkpoint anchoring and durable externally witnessed monotonic epochs.
2. A scope-specific, separately authorized and audited recovery state machine, with process-instance proof, no PID-only decisions, and ambiguous states held.
3. A real launcher confinement threat model and privileged helper design before any non-fixture execution.
4. Production Systemia, Passport, Execution Gate, capability capsule, NodeSeed integration only after live authority verification and repository reconciliation.
