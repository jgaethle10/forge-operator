# Package Transition Recovery Policy

The package transition journal is authority-bearing state. Recovery therefore requires evidence plus explicit authority.

## Inspection

`package-transition-recovery-inspector.mjs` is read-only. It verifies the raw transition event chain independently of the head checkpoint, inspects writer-lock evidence without deleting it, and validates the last transition permit against Passport when evaluating a one-event checkpoint lag.

Inspection grants no repair authority.

## Recovery planning

`package-transition-recovery.mjs` may prepare only narrowly defined operations:

- `repair_head_checkpoint`, requiring Passport scope `app.recover.head`;
- `clear_writer_lock`, requiring Passport scope `app.recover.writer`.

A plan is bound to the exact state directory fingerprint, resource, evidence hash, event count, raw head receipt, writer-lock hash, process-instance evidence, and request fingerprint.

## Writer-lock recovery

New writer locks include an `evercraft.os.process-instance.v1` identity. On Linux this binds the writer to boot ID, PID, and `/proc` process-start ticks.

A writer lock can be prepared for clearing only when:

- the lock is old enough to satisfy the configured minimum age;
- the lock contains process-instance evidence;
- the current machine observation proves the original process instance is absent, its PID has been reused, or the machine boot ID changed;
- the lock bytes still match the evidence hash when mutation occurs;
- a caller supplies the exact single-use `app.recover.writer` Passport permit.

A live matching writer is never cleared. A legacy v1 lock without process-instance evidence is never cleared automatically or through this recovery executor.

## Crash semantics

Recovery uses an append-only recovery journal:

1. fsync recovery intent;
2. consume exact Passport recovery permit;
3. perform deterministic repair;
4. append completion receipt.

If power is lost after step 2, the same consumed permit can resume the same intent. If power is lost after step 3, the next attempt records `observed_already_applied` and closes the receipt chain. It does not mint new authority.

A conflicting incomplete recovery intent blocks another recovery mutation.

## Ambiguous evidence

Corrupt transition history, ambiguous checkpoint divergence, changed lock bytes, unverifiable process identity, or a live writer are held. Recovery does not guess.
