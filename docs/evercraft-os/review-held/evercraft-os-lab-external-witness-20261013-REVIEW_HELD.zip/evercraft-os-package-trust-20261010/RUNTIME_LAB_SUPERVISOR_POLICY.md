# Evercraft OS lab process supervisor | Candidate 2026-10-12

**Status: REVIEW HELD, LAB-ONLY. Not merged, not released, not deployed.**

## Demonstrated

This additive, offline Linux proof advances the runtime handoff from read-only evidence inspection to a **real, narrow process lifecycle exercise**. The `EvercraftOsLabRuntimeSupervisor` invokes one local Node fixture with `spawn()` (no shell) only after verifying:

- lab supervisor is explicitly enabled; Linux and non-root caller;
- four independent Ed25519-signed role attestations pass the existing runtime gate verifier;
- exact subject/plan/node/product binding, and a distinct pinned Ed25519 **lab** launch permit with a 60-second max lifetime;
- exact immutable-test-fixture content hash and local Node binary hash, with no symlinked components;
- an exclusive per-node/product writer reservation **before** consuming a lab permit;
- single-use durable consumption receipt **before** spawning;
- an unpredictable challenge echoed over fixture IPC, distinct from independently checked Linux boot-ID/PID/start-tick identity.

A separate signed `lab.runtime.stop` permit bound to the same plan and observed process instance is required to terminate a fixture. SIGTERM is sent first; SIGKILL only if it is still the same Linux process instance after grace time. A rejected stop does not signal. Process exit is recorded in a local fsynced JSONL audit trail, and the owned lock is released only after its unique token is checked.

## Security truth boundary

- **Not a production Passport permit**: `lab.runtime.launch` and `lab.runtime.stop` are separately signed, synthetic fixture permit schemas. They cannot stand in for live Passport.
- Four signed decisions are only format-checked under test-enrolled, ephemeral keys. They are **not real Systemia/Execution Gate/capsule/NodeSeed deployments or approvals**.
- This is **not a sandbox**: the fixture inherits a non-root UID, but there are no namespaces, seccomp, cgroups, network isolation, chroot, mandatory access controls, or privilege-separated launcher. Fixture JavaScript is trusted lab source, not user-submitted code.
- A hash check before `spawn()` is subject to path/content TOCTOU; no fd-pinned `execveat`/`fexecve` integrity mechanism is established.
- IPC readiness and proc identity are not real application health or business readiness. No claim of production launch, externally controlled services, device permissions, or completed remote job.
- One-use permit evidence persists with fsync and create-exclusive semantics. Crash ambiguity holds the lock for manual review. It is **not automatic recovery** or a complete consensus/transaction log.
- Local JSONL event receipts are fsynced but **not cryptographically chained**; do not represent them as tamper-evident or external audit anchoring.
- No network routes, public API, customer actions, Docker, SSH, root privileges, OS installation or deploy automation.
- The archived recovered `systemia/passport/passport.mjs` remains a TEST dependency only.

## Test commands

Run Node 22+ **as an unprivileged Linux user**, with `node` available:

```sh
node --test systemia/evercraft-os/*.test.mjs
```

The new cases include launch and termination, missing or forged approvals, expired/replayed permits, concurrency, lock ownership replacement, existing unresolved locks, refusal of unsafe scopes, no-ready process timeouts, unpinned or symlinked fixture and process identity capture. Test keys are ephemeral in memory.

## Next gates (not satisfied)

1. Reconcile actual canonical source when GitHub access is restored or a separately attested sovereign repo is available.
2. Substitute real Systemia/Passport/Execution Gate/NodeSeed registered authorities and independently anchored signer enrollment; never promote fixture signatures.
3. Architect the privileged, confined native launcher with immutable fd-pinned executables, UID separation, seccomp, namespaces, cgroups, encrypted secret handoff and device controls. Threat model before general code execution.
4. Implement a durable hash-chained lifecycle journal with recovery permit scope, ambiguity inspection, crash tests and independent checkpoint anchor.
5. Verify health via bounded authenticated app probes and external observation, clearly separating liveness/readiness from application correctness.
6. Test on isolated non-production hardware and full canonical CI. Real HP/Chromebook deployments remain outside this candidate.
